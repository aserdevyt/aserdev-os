# Stripe

This plugin provides completion for the [Stripe CLI](https://stripe.com/docs/stripe-cli).

To use it add stripe to the plugins array in your zshrc file.

```bash
plugins=(... stripe)
```
